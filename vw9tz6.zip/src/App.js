import "./styles.css";

export default function App() {
  return (
    <div className="App">
      <h1></h1>
      <h2>Start</h2>
    </div>
  );
}
