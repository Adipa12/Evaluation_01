import React from "react";
// import { createRoot } from "react-dom/client";
import ReactDOM from "react-dom";
import Button from "./Button";
import Avatar from "./Avatar";

// import App from "./App";

const App = () => {
  return (
    <div className="App">
      <Button />
      <Avatar caption="Aditya" image="https://via.placeholder.com/150" />
    </div>
  );
};
const rootElement = document.getElementById("root");
ReactDOM.render(<App />, rootElement);

export { Button, Avatar };
