import React from 'react';

const style = {
  backgroundColor: 'tomato',
  padding: '1rem',
};

const Button = () => {
  return <button style={style}>Click Me
  </button>;
};

export default Button;