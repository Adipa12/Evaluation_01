import React from "react";

const style = {
  borderRadius: "50%"
};

const Avatar = ({ caption, image }) => {
  return (
    <div>
      <h2>{caption}</h2>
      <img src={image} alt={caption} style={style} />
    </div>
  );
};

export default Avatar;
